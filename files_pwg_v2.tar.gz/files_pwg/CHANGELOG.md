CHANGELOG
=========

0.8.1
-----
 
 * fix Translation
 * Autocompletion with incomplete directory name
 * Fix move multiple files reload page reload bug

0.8.0
-----

 * Licence change to AGPL
 * Unit tests for MoveController (CompleteController test is shit)
 * translation of various languages

0.7.3a
------

 * fix xml error in appinfo/info.xml

0.7.3
-----

 * initial OC8 support

 missing features:
  
  * translation
  * unit tests

