OC.L10N.register(
    "oc_files_mv",
    {
    "No filesystem found" : "Nenhum arquivo de sistema encontrado",
    "No data supplied." : "Nenhum dado fornecido.",
    "Src and Dest are not allowed to be the same location!" : "Não é permitido Fonte e Destino serem a mesma localização!",
    "Could not move %s - File with this name already exists" : "Impossível mover %s - Já existe um arquivo com esse nome",
    "Could not move %s" : "Impossível mover %s",
    "Move" : "Mover",
    "Copy" : "Copiar",
    "Destination directory" : "Diretório de destino"
},
"nplurals=2; plural=(n > 1);");
