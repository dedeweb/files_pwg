OC.L10N.register(
    "oc_files_mv",
    {
    "No filesystem found" : "Nenhum sistema de ficheiros encontrado",
    "No data supplied." : "Nenhuns dados especificados.",
    "Src and Dest are not allowed to be the same location!" : "Src e Dest não podem ter a mesma localização!",
    "Could not move %s - File with this name already exists" : "Não foi possível mover %s - Já existe um ficheiro com este nome",
    "Could not move %s" : "Não foi possível mover %s",
    "Move" : "Mover",
    "Copy" : "Copiar",
    "Destination directory" : "Directório de destino"
},
"nplurals=2; plural=(n != 1);");
