<?php
$TRANSLATIONS = array(
"No filesystem found" => "Kein Dateisystem gefunden",
"No data supplied." => "Keine Daten angegeben.",
"Src and Dest are not allowed to be the same location!" => "Quelle und Ziel dürfen nicht derselbe Ort sein!",
"Could not move %s - File with this name already exists" => "Konnte %s nicht verschieben. Eine Datei mit diesem Namen existiert bereits",
"Could not move %s" => "Konnte %s nicht verschieben",
"Move" => "Verschieben",
"Copy" => "Kopieren",
"Destination directory" => "Zielordner"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
