OC.L10N.register(
    "oc_files_mv",
    {
    "No filesystem found" : "Ningún archivo de sistema encontrado",
    "No data supplied." : "No se ha especificado los datos",
    "Src and Dest are not allowed to be the same location!" : "Origen y Destino No pueden ser el mismo!",
    "Could not move %s - File with this name already exists" : "No se pudo mover %s - Ya existe un archivo con ese nombre.",
    "Could not move %s" : "No se pudo mover %s",
    "Move" : "Mover",
    "Copy" : "Copiar",
    "Destination directory" : "Directorio de destino"
},
"nplurals=2; plural=(n != 1);");
