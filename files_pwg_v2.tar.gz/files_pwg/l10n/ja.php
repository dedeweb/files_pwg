<?php
$TRANSLATIONS = array(
"No filesystem found" => "ファイルシステムが見つかりません",
"No data supplied." => "データが指定されていません。",
"Src and Dest are not allowed to be the same location!" => "移動元と移動先を同じ場所にすることはできません！",
"Could not move %s - File with this name already exists" => "%s を移動できませんでした ― この名前のファイルはすでに存在します",
"Could not move %s" => "%s を移動できませんでした",
"Move" => "移動",
"Copy" => "コピー",
"Destination directory" => "移動先ディレクトリ"
);
$PLURAL_FORMS = "nplurals=1; plural=0;";
