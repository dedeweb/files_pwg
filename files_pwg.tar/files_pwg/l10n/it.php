<?php
$TRANSLATIONS = array(
"No filesystem found" => "Nessun filesystem trovato",
"No data supplied." => "Nessun dato fornito.",
"Src and Dest are not allowed to be the same location!" => "Origine e destinazione non possono essere la stessa posizione!",
"Could not move %s - File with this name already exists" => "Impossibile spostare %s - un file con questo nome esiste già",
"Could not move %s" => "Impossibile spostare %s",
"Move" => "Sposta",
"Copy" => "Copia",
"Destination directory" => "Cartella di destinazione"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
