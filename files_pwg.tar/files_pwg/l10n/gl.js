OC.L10N.register(
    "oc_files_mv",
    {
    "No filesystem found" : "Non se atopou un sistema de ficheiros",
    "No data supplied." : "Non se forneceron datos.",
    "Src and Dest are not allowed to be the same location!" : "Orixe e destino non poden ser a mesma localización!",
    "Could not move %s - File with this name already exists" : "Non foi posíbel mover %s; Xa existe un ficheiro con ese nome.",
    "Could not move %s" : "Non foi posíbel mover %s",
    "Move" : "Mover",
    "Copy" : "Copiar",
    "Destination directory" : "Directorio de destino"
},
"nplurals=2; plural=(n != 1);");
