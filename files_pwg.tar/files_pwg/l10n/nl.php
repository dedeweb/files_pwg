<?php
$TRANSLATIONS = array(
"No filesystem found" => "Geen bestandssysteem gevonden",
"No data supplied." => "Geen gegevens aangeleverd.",
"Src and Dest are not allowed to be the same location!" => "Bron en Doel mogen niet dezelfde locatie zijn!",
"Could not move %s - File with this name already exists" => "Kon %s niet verplaatsen - Er bestaat al een bestand met deze naam",
"Could not move %s" => "Kon %s niet verplaatsen",
"Move" => "verplaatsen",
"Copy" => "Kopiëren",
"Destination directory" => "Doelmap"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
