OC.L10N.register(
    "oc_files_mv",
    {
    "No filesystem found" : "Нема фајл-система",
    "No data supplied." : "Нема података.",
    "Src and Dest are not allowed to be the same location!" : "Извор и одредиште не могу бити исти!",
    "Could not move %s - File with this name already exists" : "Не могу да преместим %s – фајл са овим називом већ постоји",
    "Could not move %s" : "Не могу да преместим %s",
    "Move" : "Премести",
    "Copy" : "Копирај",
    "Destination directory" : "Одредишни директоријум"
},
"nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2);");
