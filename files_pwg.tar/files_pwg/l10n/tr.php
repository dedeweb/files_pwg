<?php
$TRANSLATIONS = array(
"No filesystem found" => "Dosya sistemi bulunamadı",
"No data supplied." => "Hiçbir veri sağlanmadı",
"Src and Dest are not allowed to be the same location!" => "Kaynak ve Hedefin aynı olmasına izin verilmiyor!",
"Could not move %s - File with this name already exists" => "%s taşınamadı. Bu isimde dosya zaten mevcut",
"Could not move %s" => "%s taşınamadı",
"Move" => "Taşı",
"Copy" => "Kopyala",
"Destination directory" => "Hedef dizini"
);
$PLURAL_FORMS = "nplurals=2; plural=(n > 1);";
