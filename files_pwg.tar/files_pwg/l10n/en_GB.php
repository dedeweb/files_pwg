<?php
$TRANSLATIONS = array(
"No filesystem found" => "No filesystem found",
"No data supplied." => "No data supplied.",
"Src and Dest are not allowed to be the same location!" => "Src and Dest are not allowed to be the same location!",
"Could not move %s - File with this name already exists" => "Could not move %s - File with this name already exists",
"Could not move %s" => "Could not move %s",
"Move" => "Move",
"Copy" => "Copy",
"Destination directory" => "Destination directory"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
