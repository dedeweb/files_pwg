<?php
$TRANSLATIONS = array(
"No filesystem found" => "Filsystem ikke funnet",
"No data supplied." => "Ingen data angitt.",
"Src and Dest are not allowed to be the same location!" => "Kilde og destinasjon kan ikke være like!",
"Could not move %s - File with this name already exists" => "Kan ikke flytte %s - En fil med samme navn finnes allerede",
"Could not move %s" => "Kunne ikke flytte %s",
"Move" => "Flytt",
"Copy" => "Kopier",
"Destination directory" => "Målkatalog"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
